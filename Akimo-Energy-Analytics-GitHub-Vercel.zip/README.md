# Akimo Energy Analytics

The approved website, ready to upload to GitHub and host on Vercel. It includes the current design, the new high-resolution logo, and all six publications with original article figures and DOI links. The logo, figure previews, and full-size figures are embedded directly in `index.html`, so the page also works by itself.

The top menu ends with Contact, which leads to the email, telephone, a single LinkedIn link, and a general map of Curridabat. The map shows the area without an office or residential marker and requires internet access.

## Upload to GitHub

1. Extract the ZIP on your computer.
2. Open the GitHub repository you want to use for the website.
3. Upload the extracted files to the repository root. Replace the previous `index.html` and add `og.png` next to it when updating the existing website. The `assets` folder contains separate copies of the images for future editing.
4. Commit the changes. Keep `index.html` and `vercel.json` at the same level.

Upload the extracted contents, not the ZIP itself. The visible page images remain embedded in `index.html`, but the LinkedIn preview requires the separate public `og.png` file. For this update, upload both `index.html` and `og.png` in the same commit.

## LinkedIn preview

The HTML includes Open Graph and X metadata pointing to `https://akimo-energy-analytics.vercel.app/og.png`. The title is Akimo Energy Analytics, with a branded landscape card using the approved logo. Keep the filename exactly `og.png`.

After Vercel finishes deploying both files, open `https://akimo-energy-analytics.vercel.app/og.png` to confirm the image loads. Then inspect the page URL `https://akimo-energy-analytics.vercel.app/` in [LinkedIn Post Inspector](https://www.linkedin.com/post-inspector/). If an existing profile attachment keeps its old thumbnail, edit that attachment and add the link again.

The preview uses the public Vercel page. A private Sites link or a local HTML file cannot provide a public image to LinkedIn. If you later move the page to another domain, update the canonical link and all Open Graph/X URL fields in the HTML to that domain.

## Deploy with Vercel

Import this GitHub repository into Vercel, or use your existing Vercel project if it is already connected to that repository. For an existing project, confirm that its Root Directory points to the folder containing `index.html`.

The included `vercel.json` configures this static website with the following settings:

| Setting | Value |
| --- | --- |
| Framework Preset | Other |
| Root Directory | Repository root |
| Build Command | Empty; no build step |
| Install Command | Empty; no dependencies |
| Output Directory | `.` |

Deploy the updated repository from Vercel. These settings follow Vercel's [static-site build instructions](https://vercel.com/docs/builds/configure-a-build#skip-build-step) and [configuration reference](https://vercel.com/docs/project-configuration/vercel-json).

## Files and future edits

| File or folder | Contents |
| --- | --- |
| `index.html` | Complete standalone page, styles, JavaScript, logo, and all figures |
| `og.png` | Public LinkedIn / social-preview image; upload next to `index.html` |
| `assets/akimo-logo-hires.png` | Approved logo |
| `assets/publications/*.webp` | Six lightweight figure previews |
| `assets/publications/*.png` | Separate copies of the six full-size original figures |
| `PUBLICATION_ASSETS.md` | Figure sources and credits |
| `vercel.json` | Static hosting configuration |

Edit `index.html` to change the text, layout, colours, or links. The publications begin at the section with `id="publications"`. Image data is embedded in the image elements and in the `embedded-figures` block near the bottom. Keep those data blocks intact when editing page text. Changing a separate image file does not automatically update its embedded copy.

To preview the page, open `index.html` in your browser. The logo and figures load from the HTML itself; the interactive map, DOI links, and LinkedIn require an internet connection. Full-size figure links use JavaScript to open the embedded PNGs in a new tab.
