# Akimo Energy Analytics

The approved website, ready to upload to GitHub and host on Vercel. It includes the current design, the new high-resolution logo, and all six publications with original article figures and DOI links.

## Upload to GitHub

1. Extract the ZIP on your computer.
2. Open the GitHub repository you want to use for the website.
3. Upload the extracted files and the complete `assets` folder to the repository root. Replace the previous `index.html` when updating the existing website.
4. Commit the changes. `index.html`, `vercel.json`, and `assets` must sit at the same level.

Upload the extracted contents, not the ZIP itself. Keep every image inside its original folder.

## Deploy with Vercel

Import this GitHub repository into Vercel, or use your existing Vercel project if it is already connected to that repository. For an existing project, confirm that its Root Directory points to the folder containing `index.html`.

The included `vercel.json` configures this static website with the following settings:

| Setting | Value |
| --- | --- |
| Framework Preset | Other |
| Root Directory | Repository root |
| Build Command | Empty; no build step |
| Install Command | Empty; no dependencies |
| Output Directory | `.` |

Deploy the updated repository from Vercel. These settings follow Vercel's [static-site build instructions](https://vercel.com/docs/builds/configure-a-build#skip-build-step) and [configuration reference](https://vercel.com/docs/project-configuration/vercel-json).

## Files and future edits

| File or folder | Contents |
| --- | --- |
| `index.html` | Complete page, embedded CSS styles, and JavaScript |
| `assets/akimo-logo-hires.png` | Approved logo |
| `assets/publications/*.webp` | Six lightweight figure previews |
| `assets/publications/*.png` | Six full-size figures opened from the page |
| `PUBLICATION_ASSETS.md` | Figure sources and credits |
| `vercel.json` | Static hosting configuration |

Edit `index.html` to change the text, layout, colours, or links. The publications begin at the section with `id="publications"`. Preserve the image filenames and folder structure unless you also update their references in the HTML.

For a local preview, serve this folder with a local web server. For example, if Python is installed, run `python -m http.server 8000` in this folder and open `http://localhost:8000`. The image paths are designed for a website served from its domain root.
