# Publication figures

All six displayed figures come from the user's original published-article PDFs. No generated figures, reconstructed data, preprint substitutes, journal covers, or remotely hotlinked images are used. DOI links identify the source articles. These files are not distributed under a new reuse licence; the original rights holders retain their rights.

| Asset stem | Article DOI | Original figure | Author credit |
| --- | --- | --- | --- |
| mexico-fig1 | https://doi.org/10.1016/j.egycc.2026.100240 | Figure 1, page 6: wind speed and global horizontal irradiance resource maps | Andrea Navarro Jiménez |
| investability-fig2 | https://doi.org/10.1016/j.jup.2026.102227 | Figure 2, page 10: NPV comparisons for Costa Rica and the UK in 2030 and 2060 | Andrea Navarro Jiménez |
| crucitas-fig2 | https://doi.org/10.1016/j.resourpol.2026.105942 | Figure 2, page 9: remote-sensing change proxies and area-level summaries | Andrea Navarro Jiménez |
| china-fig2 | https://doi.org/10.1016/j.fuel.2025.136326 | Figure 2, page 3: land suitability for renewable-hydrogen infrastructure | Andrea Navarro Jiménez |
| waste-fig3 | https://doi.org/10.1016/j.jclepro.2025.147103 | Figure 3, page 8: provincial recycling performance and system dynamics | Andrea Navarro Jiménez |
| roadmap-fig1 | https://doi.org/10.1016/j.ref.2024.100651 | Figure 1, page 3: solar irradiance and wind-speed distributions across Costa Rica | Andrea Navarro Jiménez and Huaili Zheng |

## Image processing

- Full-size PNG images are stored in `assets/publications/` and open separately from the journal links.
- Five PNGs were extracted directly with Poppler's `pdfimages`. The roadmap figure was rendered at 300 dpi from its exact PDF figure bounding box because direct PNG extraction produced an invalid image.
- WebP thumbnails are proportionally downsampled to a maximum dimension of 900 pixels and encoded at quality 88. They are used for in-page loading only; the full-size figure remains available.
- No scientific content, chart labels, axes, colours, panel labels, or geographic boundaries were redrawn or removed. CSS uses `object-fit: contain` to preserve the complete figure.
- Journal issue years follow the user-supplied citations and published PDFs. In particular, Fuel is a 2026 issue although its DOI and online publication date are from 2025.

## Source and access

All titles and DOI values were checked against the published PDFs supplied by the user. Full PDFs, personal contact information from the articles, proof drafts, and Library identifiers are not included in the public assets folder. Article links lead to the publisher via DOI and may require access through the publisher.
