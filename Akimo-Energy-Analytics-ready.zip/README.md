# Akimo Energy Analytics

Akimo Energy Analytics is an independent research and analytics initiative focused on clean-energy transitions, including renewable energy, green hydrogen, decarbonisation, geospatial analysis, and climate and energy policy.

## Website

This repository contains a static website that can be deployed directly with Vercel.

### Files

- `index.html` — main website
- `README.md` — project information

The Akimo logo is embedded directly in `index.html`, so no separate image asset is required for this version.

## Deployment with Vercel

1. Push the repository to GitHub.
2. In Vercel, choose **Add New → Project**.
3. Import the GitHub repository `Akimo-Energy-Analytics`.
4. Leave the framework preset as **Other** (or the detected static option).
5. Leave the root directory blank.
6. Deploy.

No build command is required.
